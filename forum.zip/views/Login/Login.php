<div class="aside_head"><p>Logowanie</p></div>
            <div class="aside_body_login_">
                  
                  <div class="form-group">
                    <div class="aside_centr"> 
                      <form action="http://localhost/forum/login" method="POST">
                        <input type="text" class="form-control bt-marg-10" id="inputDefault" placeholder="Login" name="Login">
                        <input type="password" class="form-control bt-marg-10" id="inputDefault" placeholder="Password" name="Pass">
                        <input type="submit" class="butn br-marg-10" value="Login">
                      </form>
                      <div class="login-helpers">
                      <a href=""></br>Zarejestruj się </a>
                      <a href=""></br>Zapomniałem Hasła </a>
                      </div>
                    </div>
                  </div>
            </div>
        </div>


 <div class="box-global">
    <div class="top-bar">

    
    </div>

    <div class="content">
      <div class="section">
        <div class="col-head"><h5>Sprawy Forum</h5></div>
        <div class="column">
          

            <div class="ucolumn">
              
            </div>
            <div class="przerwa"></div>
            
            <div class="ucolumn">
				
            </div>
            <div class="przerwa"></div>
            
            <div class="ucolumn">

            </div>
            <div class="przerwa"></div>

        </div>
      </div>

        <div class="aside">
            <div class="aside_head"><p>Logowanie</p></div>
            <div class="aside_body_login">
                  
                  <div class="form-group">
                    <div class="aside_centr"> 
                      <form action="http://localhost/forum/login" method="POST">
                        <input type="text" class="form-control bt-marg-10" id="inputDefault" placeholder="Login" name="Login">
                        <input type="password" class="form-control bt-marg-10" id="inputDefault" placeholder="Password" name="Pass">
                        <input type="submit" class="butn br-marg-10" value="ZALOGUJ">
                      </form>
                      <div class="login-helpers">
                      <a href="http://localhost/forum/register"></br>Zarejestruj się </a>
                      <a href=""></br>Zapomniałem Hasła </a>
                      </div>
                    </div>
                  </div>
            </div>
        </div>
      <div class="clr-both"></div><pre><?php print_r($_SERVER)?></pre>
    </div>
</div>
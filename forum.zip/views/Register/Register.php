<!DOCTYPE HTML>
<html>
<head>
    <title>Forum</title>
    <meta charset="utf-8"/>
    <link rel="stylesheet" href="http://localhost/forum/views/SRC/CSS/bootswatch.css" type="text/css" media="all"/> 
    <link rel="stylesheet" href="main.css" type="text/css" />
    
</head>



<body>
<div class="aside_head"><p>Rejestracja</p></div>
            <div class="aside_body_login_">
                  
                  <div class="form-group">
                    <div class="register"> 
                      <form action="http://localhost/forum/Register" method="POST">
                        <input type="text" class="form-control bt-marg-10 register" id="inputDefault" placeholder="Login" name="Login">
                        <input type="text" class="form-control bt-marg-10 register" id="inputDefault" placeholder="E-Mail" name="Mail">
                        <input type="password" class="form-control bt-marg-10 register" id="inputDefault" placeholder="Password" name="Pass">
                        <input type="password" class="form-control bt-marg-10 register" id="inputDefault" placeholder="Repeat Password" name="Pass2">
                        <div class="g-recaptcha" data-sitekey="6LfqeicTAAAAAJUcI52pdxEW51b97SBzr0UHc9AJ"></div>
                        <input type="submit" class="butn br-marg-10" value="Register">
                      </form>
                      <div class="login-helpers">
                      <a href=""></br>Zarejestruj się </a>
                      <a href=""></br>Zapomniałem Hasła </a>
                      </div>
                    </div>
                  </div>
            </div>
        </div>
<?php

class Register_model extends Model {
    function __construct(){
        parent::__construct();
            if(isSet($_POST['Login'])){
            $this->register();
            $this->cfg = new Config; 
            }
        }
       
    

        private function register(){
                    if ($this->validation=true){
                        //  $this->pdo->prepare("INSERT INTO");
                        
                    
                    }
        
            }
        private function validation(){  
                    $login=$_POST['Login'];
                    $pass=$_POST['Pass'];
                    $pass2=$_POST['Pass2'];
                    $mail=$_POST['Mail'];

// Checking 
                    $num=strlen($login);
                    if($num>$cfg->min_lwn && $num<$cfg->max_lwn){
                        $validation=true;
                    }else{
                        $validation=false;
                    }
                    
            return $validation;
        }
    }
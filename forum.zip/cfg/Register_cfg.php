<?php
class Register_CFG extends Config {
    function __construct(){
        parent::__construct();
            if(isSet($_POST['Login'])){
            $this->register();
            }
        }
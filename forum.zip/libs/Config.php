<?php

class Config {
function __construct() {
    
}
$this->min_lwn=2;
$this->max_lwn=12;

}
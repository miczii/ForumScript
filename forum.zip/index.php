<?php
session_start();
require 'libs/router.php';
require 'libs/Controller.php';
require 'libs/Model.php';
require 'libs/View.php';
//require 'models/construct_DB.php';


$router=new Router;